import { Button } from "@/components/ui/button";
import { ChevronRight, MapPin, Phone, Mail } from "lucide-react";
import { useState, useEffect } from "react";

/**
 * Design Philosophy: Refined Minimalism with Warm Luxury
 * - Warm color palette (brown, gold, cream)
 * - Asymmetric layouts with generous whitespace
 * - Serif display typography for elegance
 * - Subtle animations and smooth transitions
 */

export default function Home() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled ? "bg-background/95 backdrop-blur shadow-sm" : "bg-transparent"
        }`}
      >
        <div className="container flex items-center justify-between h-20">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-serif-display font-bold text-lg">
                BD
              </span>
            </div>
            <span className="font-serif-display text-xl font-bold text-primary hidden sm:inline">
              Brown Dutch Iconic
            </span>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <a href="#collections" className="text-sm font-medium hover:text-accent transition">
              Collections
            </a>
            <a href="#about" className="text-sm font-medium hover:text-accent transition">
              About
            </a>
            <a href="#brands" className="text-sm font-medium hover:text-accent transition">
              Brands
            </a>
            <a href="#contact" className="text-sm font-medium hover:text-accent transition">
              Contact
            </a>
          </nav>
          <Button variant="outline" size="sm">
            Visit Store
          </Button>
        </div>
      </header>

      {/* Hero Section - Asymmetric Layout */}
      <section className="pt-32 pb-20 relative overflow-hidden">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left: Text Content */}
            <div className="space-y-8 animate-fade-in">
              <div className="space-y-4">
                <p className="text-accent font-serif-accent text-lg italic">
                  Curated Luxury Eyewear
                </p>
                <h1 className="font-serif-display text-5xl lg:text-6xl font-bold leading-tight">
                  Look and Feel
                  <span className="block text-accent">Iconic</span>
                </h1>
                <p className="text-lg text-muted-foreground max-w-md leading-relaxed">
                  Experience the art of eyewear styling. Premium frames, Italian acetate, and
                  personalized service that transforms how you see yourself.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-primary hover:bg-primary/90">
                  Explore Collections
                  <ChevronRight className="ml-2 w-4 h-4" />
                </Button>
                <Button variant="outline" size="lg">
                  Book Styling Session
                </Button>
              </div>
              <div className="pt-8 border-t border-border">
                <p className="text-sm text-muted-foreground mb-3">Featured in</p>
                <div className="flex gap-6 opacity-60">
                  <span className="font-serif-display font-bold">Qoi</span>
                  <span className="font-serif-display font-bold">Carrera</span>
                  <span className="font-serif-display font-bold">Charriol</span>
                </div>
              </div>
            </div>

            {/* Right: Hero Image */}
            <div className="relative h-96 lg:h-full min-h-96 rounded-lg overflow-hidden shadow-2xl">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663510074444/Uv2WKeJHpYU8rsj2ew3U9M/hero_eyewear_showcase-LQY7k2be7za5SjTxfywcB8.webp"
                alt="Premium eyewear showcase"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-background/20 to-transparent"></div>
            </div>
          </div>
        </div>

        {/* Decorative divider line */}
        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-accent to-transparent opacity-30"></div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-card">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left: Image */}
            <div className="relative h-96 rounded-lg overflow-hidden shadow-lg order-2 lg:order-1">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663510074444/Uv2WKeJHpYU8rsj2ew3U9M/boutique_interior-Ko387KjptRrpbavDxLNjE9.webp"
                alt="Luxury boutique interior"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Right: Content */}
            <div className="space-y-6 order-1 lg:order-2">
              <div>
                <p className="text-accent font-serif-accent text-lg italic mb-2">Our Story</p>
                <h2 className="font-serif-display text-4xl font-bold mb-4">
                  The Non-Clinical Boutique Experience
                </h2>
              </div>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Brown Dutch Iconic reimagines eyewear retail as a luxury experience. We've
                deliberately excluded medical optometry services to focus entirely on what we do
                best: curating exceptional frames and providing personalized styling that enhances
                your professional image.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Every frame in our collection tells a story of craftsmanship—from Italian acetate
                to German engineering. We believe eyewear should be treasured for a lifetime, not
                merely functional.
              </p>
              <div className="pt-4 space-y-3">
                <div className="flex gap-3">
                  <div className="w-1 bg-accent"></div>
                  <p className="text-sm font-medium">Premium curated collections</p>
                </div>
                <div className="flex gap-3">
                  <div className="w-1 bg-accent"></div>
                  <p className="text-sm font-medium">Expert personal styling</p>
                </div>
                <div className="flex gap-3">
                  <div className="w-1 bg-accent"></div>
                  <p className="text-sm font-medium">Luxury boutique atmosphere</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Collections Section */}
      <section id="collections" className="py-20">
        <div className="container">
          <div className="text-center mb-16">
            <p className="text-accent font-serif-accent text-lg italic mb-2">Our Collections</p>
            <h2 className="font-serif-display text-4xl font-bold">
              Curated Eyewear for Every Style
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Collection Card 1 */}
            <div className="group cursor-pointer">
              <div className="relative h-80 rounded-lg overflow-hidden shadow-lg mb-4 transition-transform duration-300 group-hover:shadow-2xl">
                <img
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663510074444/Uv2WKeJHpYU8rsj2ew3U9M/frame_detail_hero-XXaN5TjCUZeoUVkQ3RKH59.webp"
                  alt="Premium frames collection"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <h3 className="font-serif-display text-2xl font-bold mb-2">Premium Frames</h3>
              <p className="text-muted-foreground mb-4">
                Italian acetate and German engineering combined for timeless elegance.
              </p>
              <a href="#" className="text-accent font-medium inline-flex items-center gap-2 hover:gap-3 transition-all">
                Explore <ChevronRight className="w-4 h-4" />
              </a>
            </div>

            {/* Collection Card 2 */}
            <div className="group cursor-pointer">
              <div className="relative h-80 rounded-lg overflow-hidden shadow-lg mb-4 transition-transform duration-300 group-hover:shadow-2xl">
                <img
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663510074444/Uv2WKeJHpYU8rsj2ew3U9M/professional_styling-FgCDCRMoF7ahZTzEwjrvnB.webp"
                  alt="Professional styling"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <h3 className="font-serif-display text-2xl font-bold mb-2">Corporate Styles</h3>
              <p className="text-muted-foreground mb-4">
                Classic frames designed for the legal and financial professionals.
              </p>
              <a href="#" className="text-accent font-medium inline-flex items-center gap-2 hover:gap-3 transition-all">
                Explore <ChevronRight className="w-4 h-4" />
              </a>
            </div>

            {/* Collection Card 3 */}
            <div className="group cursor-pointer">
              <div className="relative h-80 rounded-lg overflow-hidden shadow-lg mb-4 transition-transform duration-300 group-hover:shadow-2xl">
                <img
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663510074444/Uv2WKeJHpYU8rsj2ew3U9M/brand_aesthetic-DcxMnhjnVLzXfrbfsvDhfd.webp"
                  alt="Luxury accessories"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <h3 className="font-serif-display text-2xl font-bold mb-2">Luxury Accessories</h3>
              <p className="text-muted-foreground mb-4">
                Premium leather cases and accessories to complement your frames.
              </p>
              <a href="#" className="text-accent font-medium inline-flex items-center gap-2 hover:gap-3 transition-all">
                Explore <ChevronRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Brands Section */}
      <section id="brands" className="py-20 bg-card">
        <div className="container">
          <div className="text-center mb-16">
            <p className="text-accent font-serif-accent text-lg italic mb-2">Featured Brands</p>
            <h2 className="font-serif-display text-4xl font-bold">
              Exclusive Collections from Global Leaders
            </h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center justify-items-center">
            {["Qoi", "Carrera", "Charriol", "Guess"].map((brand) => (
              <div
                key={brand}
                className="w-full h-24 flex items-center justify-center rounded-lg bg-background border border-border hover:border-accent transition-colors"
              >
                <span className="font-serif-display text-2xl font-bold text-muted-foreground">
                  {brand}
                </span>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <p className="text-muted-foreground mb-4">
              Each brand represents the pinnacle of eyewear craftsmanship and design excellence.
            </p>
            <Button variant="outline">View All Brands</Button>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-16">
            <p className="text-accent font-serif-accent text-lg italic mb-2">Our Services</p>
            <h2 className="font-serif-display text-4xl font-bold">
              Personalized Eyewear Styling
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "Personal Styling",
                description:
                  "Our eyewear stylists work with you to find frames that enhance your face shape and professional image.",
              },
              {
                title: "Frame Fitting",
                description:
                  "Expert fitting ensures your frames sit perfectly and comfortably, optimizing both style and function.",
              },
              {
                title: "Corporate Gifting",
                description:
                  "Curated eyewear solutions for corporate clients and bulk orders with personalized service.",
              },
            ].map((service, idx) => (
              <div
                key={idx}
                className="p-8 rounded-lg bg-card border border-border hover:border-accent transition-colors"
              >
                <h3 className="font-serif-display text-2xl font-bold mb-3">{service.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="container text-center">
          <h2 className="font-serif-display text-4xl font-bold mb-4">Ready to Look Iconic?</h2>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            Visit our boutique in Cavendish Square, Cape Town, or book a personalized styling
            session with one of our expert eyewear stylists.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary">
              Book Appointment
            </Button>
            <Button size="lg" variant="outline" className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10">
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {/* Location */}
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center">
                <MapPin className="w-6 h-6 text-accent" />
              </div>
              <h3 className="font-serif-display text-xl font-bold">Location</h3>
              <p className="text-muted-foreground">
                Cavendish Square
                <br />
                Claremont, Cape Town
                <br />
                South Africa
              </p>
            </div>

            {/* Phone */}
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center">
                <Phone className="w-6 h-6 text-accent" />
              </div>
              <h3 className="font-serif-display text-xl font-bold">Phone</h3>
              <p className="text-muted-foreground">
                <a href="tel:+27216172315" className="hover:text-accent transition">
                  +27 21 617 2315
                </a>
              </p>
            </div>

            {/* Email */}
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center">
                <Mail className="w-6 h-6 text-accent" />
              </div>
              <h3 className="font-serif-display text-xl font-bold">Email</h3>
              <p className="text-muted-foreground">
                <a href="mailto:info@browndutchiconic.com" className="hover:text-accent transition">
                  info@browndutchiconic.com
                </a>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-serif-display font-bold mb-4">Brown Dutch Iconic</h4>
              <p className="text-sm text-muted-foreground">
                Premium eyewear boutique in Cape Town, specializing in luxury frames and personal
                styling.
              </p>
            </div>
            <div>
              <h4 className="font-medium mb-4">Collections</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-accent transition">
                    Premium Frames
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition">
                    Corporate Styles
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition">
                    Accessories
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-4">Brands</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-accent transition">
                    Qoi
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition">
                    Carrera
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition">
                    Charriol
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-accent transition">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition">
                    Contact
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition">
                    Privacy Policy
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center text-sm text-muted-foreground">
              <p>&copy; 2026 Brown Dutch Iconic Eyewear. All rights reserved.</p>
              <div className="flex gap-6 mt-4 md:mt-0">
                <a href="#" className="hover:text-accent transition">
                  Instagram
                </a>
                <a href="#" className="hover:text-accent transition">
                  Facebook
                </a>
                <a href="#" className="hover:text-accent transition">
                  LinkedIn
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
