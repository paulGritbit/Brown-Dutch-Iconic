# Brown Dutch Iconic Eyewear - Design Brainstorm

## Context
Brown Dutch Iconic is a luxury eyewear boutique in Cape Town that emphasizes craftsmanship, heritage, and the "iconic" lifestyle. The brand focuses on high-end frames (Italian acetate, German engineering), professional styling, and a non-clinical boutique experience. The visual identity should reflect sophistication, exclusivity, and timeless elegance.

---

## Design Approach Selected: **Refined Minimalism with Warm Luxury**

### Design Movement
**Bauhaus meets Contemporary Luxury** — A marriage of functional minimalism with warm, tactile materials. Think high-end watchmaking aesthetics: clean lines, precision, but with organic warmth through earth tones and natural textures.

### Core Principles
1. **Intentional Restraint**: Every element serves a purpose. Negative space is abundant and deliberate.
2. **Warm Sophistication**: Earth tones (warm browns, soft golds, cream) replace cold neutrals, creating an inviting luxury feel.
3. **Craftsmanship Visibility**: Typography, spacing, and micro-interactions reveal the care invested in the design.
4. **Narrative Through Curation**: The site tells the story of each frame, emphasizing heritage and artisanal quality.

### Color Philosophy
- **Primary**: Warm brown (#6B5344) — evokes leather, Italian acetate, and heritage
- **Accent**: Soft gold (#D4A574) — luxury, precision, timelessness
- **Background**: Off-white cream (#F9F7F4) — warm, inviting, gallery-like
- **Text**: Deep charcoal (#2C2C2C) — readable, sophisticated
- **Secondary**: Muted sage (#9BA89B) — balance, nature, sustainability

**Emotional Intent**: Warmth without coldness. Luxury without sterility. Craftsmanship without pretension.

### Layout Paradigm
- **Hero Section**: Full-width, asymmetric layout with image on right, text/CTA on left (breaking centered monotony)
- **Product Showcase**: Alternating left-right layouts with generous whitespace, mimicking a gallery walk
- **Typography Hierarchy**: Large serif headlines (Playfair Display) paired with refined sans-serif body (Lato)
- **Grid Avoidance**: Organic, flowing sections with varied widths and asymmetric positioning

### Signature Elements
1. **Thin Divider Lines**: Subtle gold/brown horizontal lines separating sections, evoking precision and craftsmanship
2. **Frame Spotlight Cards**: Each product displayed in a floating, shadow-enhanced card with minimal text
3. **Handwritten Accent Font**: Script typography for taglines and brand statements (e.g., "Look Iconic")

### Interaction Philosophy
- **Hover Effects**: Subtle lift and shadow deepening on product cards (not aggressive)
- **Smooth Scrolling**: Gentle fade-ins and staggered reveals as sections come into view
- **Click Feedback**: Minimal but clear—text color shifts, subtle underline appears
- **Navigation**: Sticky header with refined typography, no visual noise

### Animation
- **Entrance**: Sections fade in and slide up gently as user scrolls (0.6s duration, ease-out)
- **Hover**: Product cards lift 4px with shadow expansion (0.3s transition)
- **Micro-interactions**: Buttons have subtle color transitions, no jarring changes
- **Scroll Indicators**: Soft underline animation on navigation items as user scrolls to sections

### Typography System
- **Display Font**: Playfair Display (serif) — headlines, hero text, brand statements
  - Weights: Regular (400) for elegance, Bold (700) for emphasis
- **Body Font**: Lato (sans-serif) — body text, descriptions, UI labels
  - Weights: Regular (400) for body, Medium (500) for emphasis, Bold (700) for strong emphasis
- **Accent Font**: Cormorant Garamond (serif, italic) — taglines, testimonials, poetic statements
- **Hierarchy**:
  - H1: Playfair Display 48px, bold
  - H2: Playfair Display 36px, regular
  - H3: Playfair Display 24px, regular
  - Body: Lato 16px, regular
  - Small: Lato 14px, regular

---

## Design Rationale
This approach positions Brown Dutch Iconic as a **premium, thoughtful brand** that values **craftsmanship and heritage** over trend-chasing. The warm color palette differentiates from cold luxury (typical tech/finance aesthetics), making the brand feel more human and approachable while maintaining exclusivity. The asymmetric layouts and generous whitespace convey confidence and intentionality—hallmarks of true luxury.
